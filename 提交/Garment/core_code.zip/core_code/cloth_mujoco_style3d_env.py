import os.path as osp
import os
import sys
import mujoco
from mujoco import viewer
import ast
import time
import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional, List, Any, Literal, TypedDict, cast
import numpy as np
import json
from loguru import logger
from omegaconf import DictConfig, OmegaConf
import hydra
import imageio
from tqdm import tqdm
import xml.etree.ElementTree as ET

from envs.base_env import BaseEnvWrapper
from common.csv_data_utils import load_processed_data, JointState

# --- Type Definitions ---
ArmType = Literal["left", "right"]

class ArmConfigData(TypedDict):
    """Stores configuration and data for one arm."""
    name: ArmType
    mujoco_joint_names: List[str]
    data: List[JointState]

def get_flex_vertices(model: mujoco.MjModel, data: mujoco.MjData, flex_name: str) -> np.ndarray:
    """Retrieves the vertices of a flex object from the MuJoCo simulation."""
    try:
        flex_id = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_FLEX, flex_name)
        vert_adr = model.flex_vertadr[flex_id]
        vert_num = model.flex_vertnum[flex_id]
        if vert_num == 0:
            return np.array([])
        return data.flexvert_xpos[vert_adr: vert_adr + vert_num - 1] # the last point is ghost point
    except KeyError:
        print(f"Warning: Flexcomp '{flex_name}' not found in model.")
        return np.array([])

class MujocoStyle3dEnv(BaseEnvWrapper):
     def __init__(self, cfg: DictConfig, **kwargs):
        # First, call the base class __init__
        super().__init__(cfg)

        # --- Initialize config ---
        self.env_cfg = cfg.env
        self.sim_timestep = self.env_cfg.get("timestep", 0.002)

        # --- Initialize model and data ---
        self.model = self._load_and_configure_model() # modify the XML file based on the config
        # self.model = mujoco.MjModel.from_xml_path(self.cfg.env.model_path) # if you do not want to modify the xml
        self.data = mujoco.MjData(self.model)

        # --- Initialize attributes from csv data playback ---
        self.playback_start_time_abs: Optional[float] = None
        self.playback_end_time_abs: Optional[float] = None
        self.arms: Dict[ArmType, ArmConfigData] = {}

        # --- Initialize interpolation trackers ---
        self.time_trackers = {'left': {'idx': 0}, 'right': {'idx': 0}}        # This tracker is crucial for the step_to_time method

        # --- Initialize data load process, and original arm  configuration---
        self._init_arms_config(cfg)
        self._init_sites()        # Load set of sites

        if self.playback_start_time_abs is None:
            sys.exit("Fatal Error: Controller failed to establish a valid playback start time.")
        logger.success("MujocoSEnv initialization successful.")

        self.viewer_handle = None
        if "visualization" in cfg and cfg.visualization.get('vis_sim', False):
            logger.info("Viewer enabled. Launching passive viewer.")
            self.viewer_handle = viewer.launch_passive(self.model, self.data)
        else:
            logger.info("Viewer is disabled.")


     # ===================================================================
     # Initial Method
     # ===================================================================
     def _init_arms_config(self, cfg: DictConfig) -> None:
         """
         Initializes arms by calling the online loading function, which
         loads pre-processed clean CSV files and applies a runtime time offset.
         """
         data_cfg = cfg.data
         arm_setups = {}
         if "sim_model" in cfg and "robot" in cfg.sim_model:
             if cfg.sim_model.robot == "piper":
                 self.robot_name = "piper"
                 arm_setups = {
                     'left': {
                         'csv_path': data_cfg.robot_joints.get('left_arm_csv_path'),
                         'mujoco_joint_names': [f'joint{i}' for i in range(1, 7)] + ['joint7', 'joint8'],
                     },
                     'right': {
                         'csv_path': data_cfg.robot_joints.get('right_arm_csv_path'),
                         'mujoco_joint_names': [f'joint{i}_arm2' for i in range(1, 7)] + ['joint7_arm2', 'joint8_arm2'],
                     }
                 }
             elif cfg.sim_model.robot == "k1":
                 self.robot_name = "k1"
                 arm_setups = {
                 'left': {
                     'csv_path': data_cfg.robot_joints.get('left_arm_csv_path'),
                     'mujoco_joint_names': [f'l-j{i+1}' for i in range(7)] + ['left_finger1_joint', 'left_finger2_joint'],
                 },
                 "right": {
                     'csv_path': data_cfg.robot_joints.get('right_arm_csv_path'),
                     'mujoco_joint_names': [f'r-j{i+1}' for i in range(7)] + ['right_finger1_joint', 'right_finger2_joint'],
                 }
                }
         else:
            logger.error("No valid robot configuration found in the data config. Exiting.")
            sys.exit(1)

         for arm_name_str, setup in arm_setups.items():
             arm_name = cast(ArmType, arm_name_str)
             if not setup['csv_path']:
                 logger.warning(f"Skipping {arm_name} arm as no csv_path was provided.")
                 continue

             # Call the online loading function
             try:
                 filtered_data = load_processed_data(
                     csv_path=setup['csv_path'],
                     start_time_offset= data_cfg.get('sim_start_time', 0.0)
                 )
             except FileNotFoundError:
                 sys.exit(1)  # Exit if pre-processed file is missing

             if filtered_data:
                 mujoco_names = setup['mujoco_joint_names']
                 self.arms[arm_name] = ArmConfigData(
                     name=arm_name,
                     mujoco_joint_names=mujoco_names,
                     data=filtered_data
                 )

         # Determine the global playback timeline from the loaded, filtered data
         all_start_times = [config['data'][0]['time'] for config in self.arms.values() if config['data']]
         all_end_times = [config['data'][-1]['time'] for config in self.arms.values() if config['data']]
         if all_start_times:
             self.playback_start_time_abs = min(all_start_times)
             self.playback_end_time_abs = max(all_end_times)
             duration = self.playback_end_time_abs - self.playback_start_time_abs
             print("-" * 30)
             print("Global Playback Timeline Determined:")
             print(f"  - Absolute Start Time: {self.playback_start_time_abs:.4f}")
             print(f"  - Absolute End Time:   {self.playback_end_time_abs:.4f}")
             print(f"  - Total Duration:      {duration:.2f} seconds")
             print("-" * 30)
         else:
             logger.warning("Could not load valid data for any arm. Playback is not possible.")

     def _init_sites(self) -> None:
         """initial all site mame and id which need to track"""
         # TODO: If you don't have these sites in your XML, you need to add them or delete this function.
         # (End-Effector / Wrist Flange) sites
         self.wrist_flange_names = ['wrist_flange_left', 'wrist_flange_right']
         #  (Gripper Tip) sites
         self.gripper_tip_names = [
             'gripper_tip_1_left', 'gripper_tip_2_left',
             'gripper_tip_1_right', 'gripper_tip_2_right'
         ]

         try:
             self.wrist_flange_ids = [self.model.site(name).id for name in self.wrist_flange_names]
             self.gripper_tip_ids = [self.model.site(name).id for name in self.gripper_tip_names]
             logger.success("Successfully initialized all tracking sites.")
         except KeyError as e:
             logger.warning(f"FATAL ERROR: Site '{e.args[0]}' not found in the XML model.")
             logger.warning(
                 "Please ensure you have added 'wrist_flange_left/right' and 'gripper_tip_...' sites to your XML.")

     # ===================================================================
     # Initial XML from Config
     # ===================================================================
     def _load_and_configure_model(self) -> mujoco.MjModel:
         """
         Loads the XML file as a template, modifies it based on the config,
         and then compiles it into a MuJoCo model.
         """
         xml_path = self.env_cfg.model_path
         xml_dir = os.path.dirname(os.path.abspath(xml_path))
         print(f"Loading XML template from: {xml_path}")
         tree = ET.parse(xml_path)
         root = tree.getroot()

         # Resolve asset paths
         compiler = root.find('compiler')
         if compiler is not None:
             for attr in ['meshdir', 'texturedir']:
                 original_path = compiler.get(attr)
                 if original_path:
                     absolute_path = os.path.join(xml_dir, original_path)
                     compiler.set(attr, absolute_path)

         # 1. Configure simulation options
         option_element = root.find('option')
         option_element.set('timestep', str(self.sim_timestep))
         logger.info(f"Set Sim timestep to: {self.sim_timestep}")

         # 2. Configure cloth object
         cloth_flex_element = root.find(f".//flexcomp[@name='{self.env_cfg.sim_flex_name}']")
         if cloth_flex_element is None:
             raise ValueError(f"Could not find <flexcomp name='{self.env_cfg.sim_flex_name}'> in {xml_path}")

         # Modify the cloth's geometry (.obj file) based on the config
         if 'model_path' in self.cfg.cloth and self.cfg.cloth.model_path:
             new_obj_path = self.cfg.cloth.model_path
             cloth_flex_element.set('file', new_obj_path)
             logger.info(f"Set cloth geometry to: {new_obj_path}")

         # Modify the cloth's material properties based on the config
         if hasattr(self.cfg, 'cloth_params'):
             cloth_params = self.cfg.cloth_params
             # Modify the cloth's physical properties based on the config
             params_to_update = {
                 'stretch': 'stretch',
                 'bending': 'bend',
                 'density': 'density',
                 'friction': 'staticfriction',
                 'kinetic_friction': 'friction',
                 'damping': 'airdamping'
             }
             for param_name, xml_key in params_to_update.items():
                 if hasattr(cloth_params, param_name):
                     value = getattr(cloth_params, param_name)
                     self._update_plugin_config(cloth_flex_element, xml_key, value)

             # Modify the cloth's appearance based on the config
             asset_element = root.find('asset')
             if asset_element is None:
                 raise ValueError("XML template must have an <asset> section.")
             material_name = cloth_flex_element.get('material')
             material_element = asset_element.find(f"./material[@name='{material_name}']")
             if material_element is None:
                 raise ValueError(f"Could not find material '{material_name}' in XML assets.")
             if hasattr(cloth_params, 'rgba'):
                 rgba_str = " ".join(map(str, cloth_params.rgba))
                 material_element.set('rgba', rgba_str)
             if hasattr(cloth_params, 'specular'):
                 specular_str = " ".join(map(str, cloth_params.specular))
                 material_element.set('specular', specular_str)
             if hasattr(cloth_params, 'shininess'):
                 material_element.set('shininess', str(cloth_params.shininess))
             texture_path = getattr(cloth_params, 'texture_path', None)
             if texture_path and isinstance(texture_path, str):
                 logger.info(f"Applying texture:{texture_path}")

         else:
             logger.warning("`cloth_params` not found in `cfg.cloth`. Using default XML values.")

         # Modify the cloth's initial pose based on the config
         pose = self._get_initial_pose_from_config()
         pos_str = " ".join(map(str, pose['pos']))
         quat_str = " ".join(map(str, pose['quat']))
         cloth_flex_element.set('pos', pos_str)
         cloth_flex_element.set('quat', quat_str)
         logger.info(f"Set cloth initial pose to: pos={pos_str}, quat={quat_str}")

         # Compile the modified XML string into a model
         modified_xml_string = ET.tostring(root, encoding='unicode')
         return mujoco.MjModel.from_xml_string(modified_xml_string)

     def _update_plugin_config(self, parent_element: ET.Element, key: str, value: any):
         """help to find key in plugin config and update its value"""
         xpath = f"./plugin/config[@key='{key}']"
         config_element = parent_element.find(xpath)
         if config_element is not None:
             str_value = str(value)
             config_element.set('value', str_value)
             logger.info(f"Set cloth plugin param '{key}' to: {str_value}")
         else:
             logger.warning(f"Cloth plugin param key '{key}' not found in the XML template.")

     def _get_initial_pose_from_config(self) -> Optional[Dict[str, List[float]]]:
         """
         Loads the initial pose, prioritizing a file path if provided,
         otherwise falling back to the pose defined directly in the YAML.
         """
         cloth_cfg = self.cfg.cloth
         # Check if a specific pose file is provided
         pose_path = cloth_cfg.get('init_pose_path', None)
         if pose_path and os.path.exists(pose_path):
             try:
                 logger.info(f"Attempting to load initial pose from file: {pose_path}")
                 with open(pose_path, 'r') as f:
                     return json.load(f)
             except (FileNotFoundError, json.JSONDecodeError) as e:
                 logger.warning(f"Failed to load pose from {pose_path}: {e}. Falling back to default pose in config.")

         # If file failed, check if the pose is defined directly in the config
         pose_direct_list = cloth_cfg.get('init_pose')
         if pose_direct_list:
             logger.info("Using initial pose directly from YAML config.")
             pose_list = OmegaConf.to_container(pose_direct_list, resolve=True)
             if isinstance(pose_list, list) and len(pose_list) == 7:
                 #  [x, y, z, w, qx, qy, qz]
                 return {'pos': pose_list[0:3], 'quat': pose_list[3:7]}
             else:
                 logger.warning(f"init_pose in YAML is not a list of 7 numbers. Falling back...")

         logger.error("CRITICAL: No valid initial pose found. Using hardcoded default pose at origin.")
         return {
             'pos': [0.0, 0.0, 0.0],
             'quat': [1.0, 0.0, 0.0, 0.0]  # (w, x, y, z) 格式的单位四元数
         }

     # ===================================================================
     # Implementation of BaseEnvWrapper's abstract methods
     # ===================================================================
     def get_master_start_time(self) -> float:
         """Returns the absolute start time from the loaded data."""
         return self.playback_start_time_abs

     def get_current_sim_time(self) -> float:
         """Returns the current MuJoCo simulation time."""
         return self.data.time

     def get_sim_vertices(self) -> np.ndarray:
         """Gets the vertices of the soft body."""
         return get_flex_vertices(self.model, self.data, self.cfg.env.sim_flex_name)

     def step_to_time(self, target_time: float) -> None:
         """
         Core method: Steps the simulation forward to a specific point in time.
         This drives the robot motion and physics evolution.
         """
         while self.data.time < target_time:
             self.step()
             self.render()

     def step(self) -> None:
        """
        Steps the simulation forward by one time step, updating the arms' joint positions
        """
        current_absolute_time = self.get_master_start_time() + self.data.time
        # Update interpolated joint positions for each arm
        for arm_name, arm_config in self.arms.items():
            if not arm_config['data']:
                continue

            interpolated_positions = self._get_interpolated_positions(
                target_time=current_absolute_time,
                arm_data=arm_config['data'],
                tracker=self.time_trackers[arm_name]
            )

            if interpolated_positions:
                self._apply_arm_state(arm_config, interpolated_positions)

        # Perform one physics simulation step
        mujoco.mj_step(self.model, self.data)

     def close(self):
        if self.viewer_handle:
            self.viewer_handle.close()

     def render(self):
         if self.viewer_handle and self.viewer_handle.is_running():
             self.viewer_handle.sync()

    # ===================================================================
    # Dual Arm Controller Methods
    # ===================================================================
     def _apply_arm_state(self, arm_config: ArmConfigData, positions: List[float]) -> None:
         """
         Applies the interpolated list of joint positions to the MuJoCo model,
         using the stored joint names for mapping by index.
         """
         model, data = self.model, self.data
         joint_names = arm_config['mujoco_joint_names']

         # Expect 2 girpper joints
         num_arm_joints = len(joint_names) - 2

         if len(positions) != num_arm_joints + 1:
             logger.warning(f"Data mismatch for arm '{arm_config['name']}': "
                            f"Expected {num_arm_joints + 1} positions, but got {len(positions)}.")
             return

         # 1. Apply the 6 arm joint positions
         arm_joint_names = joint_names[:num_arm_joints]
         arm_positions = positions[:num_arm_joints]
         for name, pos in zip(arm_joint_names, arm_positions):
             try:
                 data.qpos[model.joint(name).qposadr] = pos
             except KeyError:
                 pass  # Silently ignore joints not found in the model

         # 2. Apply the gripper position (using the last value from the list)
         gripper_value = positions[-1]
         gripper_jnt1_name, gripper_jnt2_name = joint_names[-2], joint_names[-1]
         try:
             data.qpos[model.joint(gripper_jnt1_name).qposadr] = gripper_value
             data.qpos[model.joint(gripper_jnt2_name).qposadr] = -gripper_value
         except KeyError:
             pass

     def _get_interpolated_positions(self, target_time: float, arm_data: List[JointState], tracker: Dict[str, int]) -> \
     Optional[List[float]]:
         """Calculates a list of joint positions for a target time using linear interpolation."""
         if not arm_data: return None

         # Advance the tracker to find the current interpolation interval
         while tracker['idx'] < len(arm_data) - 2 and arm_data[tracker['idx'] + 1]['time'] < target_time:
             tracker['idx'] += 1

         # Handle boundary cases
         if target_time <= arm_data[0]['time']: return arm_data[0]['positions']
         if target_time >= arm_data[-1]['time']: return arm_data[-1]['positions']

         # Linear interpolation
         p0, p1 = arm_data[tracker['idx']], arm_data[tracker['idx'] + 1]
         t0, pos0_list = p0['time'], p0['positions']
         t1, pos1_list = p1['time'], p1['positions']

         interval = t1 - t0
         if interval <= 0: return pos0_list

         alpha = (target_time - t0) / interval

         # Use NumPy for clean and efficient list interpolation
         pos0_arr = np.array(pos0_list)
         pos1_arr = np.array(pos1_list)
         interpolated_pos_arr = pos0_arr + alpha * (pos1_arr - pos0_arr)

         return interpolated_pos_arr.tolist()

     # ===================================================================
     # Special Function in mujoco, to get wrist flange and gripper tip poses
     # ===================================================================
     def get_wrist_poses(self) -> List[Dict[str, Any]]:
         """get the wrist flange poses in world coordinates."""
         site_positions = self.data.site_xpos[self.wrist_flange_ids]
         site_matrices_flat = self.data.site_xmat[self.wrist_flange_ids]
         poses = []
         print("\n--- Wrist Flange Poses (World Coords) ---")
         for name, pos, mat_flat in zip(self.wrist_flange_names, site_positions, site_matrices_flat):
             quat = np.zeros(4)
             mujoco.mju_mat2Quat(quat, mat_flat)
             print(f"  - {name}: Pos={pos}, Quat(wxyz)={quat}")
             poses.append({'name': name, 'position': pos.copy(), 'orientation_quat': quat.copy()})
         return poses


     def get_gripper_tip_poses(self) -> List[Dict[str, Any]]:
         """get all gripper tip site positions and orientations."""
         site_positions = self.data.site_xpos[self.gripper_tip_ids]
         site_matrices_flat = self.data.site_xmat[self.gripper_tip_ids]
         poses = []
         print("\n--- Gripper Tip Poses (World Coords) ---")
         for name, pos, mat_flat in zip(self.gripper_tip_names, site_positions, site_matrices_flat):
             quat = np.zeros(4)
             mujoco.mju_mat2Quat(quat, mat_flat)
             print(f"  - {name}: Pos={pos}, Quat(wxyz)={quat}")
             poses.append({'name': name, 'position': pos.copy(), 'orientation_quat': quat.copy()})
         return poses

     # ===================================================================
     # Online and offline run simulation in mujoco
     # ===================================================================
     def run(self):
         """Main control loop for the simulation."""

         viewer_handle = viewer.launch_passive(self.model, self.data)

         if self.playback_start_time_abs is None:
             print("Wrong: Playback start time is not set. Cannot run simulation.")
             return

         time_trackers = {name: {'idx': 0} for name, config in self.arms.items() if config['data']}
         sim_dt = self.model.opt.timestep

         while viewer_handle.is_running():
             step_start_wall_time = time.time()
             self.step()
             # current_target_time = self.data.time + self.playback_start_time_abs
             #
             # for arm_name, config in self.arms.items():
             #     if not config['data']:
             #         continue
             #
             #
             #     # interpolated joint positions
             #     interpolated_positions = self._get_interpolated_positions(
             #         current_target_time,
             #         config['data'],
             #         time_trackers[arm_name]
             #     )
             #     if interpolated_positions:
             #         self._apply_arm_state(config, interpolated_positions)
             #
             # mujoco.mj_step(self.model, self.data)
             viewer_handle.sync()

             # if you want to print the camera pose

             time_to_wait = sim_dt - (time.time() - step_start_wall_time)
             if time_to_wait > 0:
                 time.sleep(time_to_wait)

         viewer_handle.close()

     def record_video(
             self,
             output_path: str = None,
             speed: float = 1.0,
             fps: int = 60,
             width: int = 2560 ,
             height: int = 1440,
             camera_name: Optional[str] = None
     ):
         """
         Run the simulation and record the video, you can control the playback speed with the speed parameter.
         Args:
             output_path (str): path of the output video file (e.g. "output.mp4").
                         speed (float, optional): playback speed.
                                                  1.0 = real time (default).
                                                  2.0 = 2x speed.
                                                  0.5 = 0.5x slow playback.
                                                  Default is 1.0.
             fps (int, optional): Frame rate of the video. Default is 60.
             width (int, optional): width of the video. Default is 1920.
             height (int, optional): height of the video. Default is 1080.
             camera_name: Optional[str]: Default camera viewpoint BaseEnvWrapper
        """
         print(f"--- Preparing to record video to '{output_path}' with interpolation ---")
         if speed <= 0: raise ValueError("Speed must be a positive number.")

         if camera_name:
             print(f"Using named camera: '{camera_name}'")
         else:
             print("Using default free camera.")

         if self.playback_start_time_abs is None or self.playback_end_time_abs is None:
             print("❌ Error: Playback start or end time is not set. Cannot record video.")
             return

         data_duration = self.playback_end_time_abs - self.playback_start_time_abs
         if data_duration <= 0:
             print("❌ Error: No data found.")
             return

         if output_path=="default":
             output_path = (f"{cfg.data.root}/video/simulation_{self.env_cfg.name}_{self.cfg.cloth.name}"
                                f"_step_{player.model.opt.timestep}.mp4")
         output_dir = os.path.dirname(output_path)
         os.makedirs(output_dir, exist_ok=True)

         # --- 1. Initialize simulation and rendering parameters ---
         sim_dt = self.model.opt.timestep

         # Calculate how many physical steps need to be performed in total
         total_sim_steps = int(data_duration / sim_dt)

         # Calculate the target duration and total frames of the video
         target_video_duration = data_duration / speed
         total_video_frames = int(target_video_duration * fps)

         # Calculate the time between rendering two frames (in simulation time)
         # This is the key to deciding when to “sample”.
         if total_video_frames > 0:
             render_interval = data_duration / total_video_frames
         else:
             render_interval = float('inf')  # 如果不需渲染，则间隔为无穷大

         print(f"  - Total simulation steps: {total_sim_steps}")
         print(f"  - Will render a frame every {render_interval:.4f} simulation seconds.")

         mujoco.mj_resetData(self.model, self.data)

         try:
             renderer = mujoco.Renderer(self.model, height=height, width=width)
         except ValueError as e:
             if 'Image width' in str(e) or 'Image height' in str(e):
                 print(f"⚠️ Warning: Resolution too high. Falling back to 640x480.");
                 width, height = 640, 480
                 renderer = mujoco.Renderer(self.model, height=height, width=width)
             else:
                 raise e

         frames = []
         time_trackers = {name: {'idx': 0} for name in self.arms}
         next_render_time = 0.0

         # --- 2. Main loop: Evolution of the entire simulation in physical steps---
         for step in tqdm(range(total_sim_steps), desc="Simulating Physics"):

             # --- 3. rendering judgment: check if the current simulation time has reached the moment to render the next frame ---
             if self.data.time >= next_render_time:
                 if camera_name:
                     renderer.update_scene(self.data, camera=camera_name)
                 else:
                     renderer.update_scene(self.data)
                 frames.append(renderer.render())
                 next_render_time += render_interval

             # --- 4. physical update ---
             self.step()
             self.render()
             # current_sim_time = self.data.time + self.playback_start_time_abs
             # for arm_name, config in self.arms.items():
             #     if not config['data']: continue
             #     interpolated_positions = self._get_interpolated_positions(
             #         current_sim_time,
             #         config['data'],
             #         time_trackers[arm_name]
             #     )
             #     if interpolated_positions:
             #         self._apply_arm_state(config, interpolated_positions)
             #
             # mujoco.mj_step(self.model, self.data)

         # --- 5. Save Video ---
         print(f"\nSimulation complete. Saving {len(frames)} rendered frames to video...")
         try:
             with imageio.get_writer(output_path, fps=fps) as writer:
                 for frame in tqdm(frames, desc="Saving Video"):
                     writer.append_data(frame)
             print(f"✅ Video successfully saved to '{output_path}'")
         except Exception as e:
             print(f"❌ Error saving video: {e}")
         finally:
             renderer.close()


if __name__ == "__main__":
    try:
        PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    except NameError:
        PROJECT_ROOT = os.getcwd()

    print("Running MujocoStyle3dEnv in standalone debug mode...")
    data_path = '/home/hwk/DataSets/Piper_Data/Official/beige_hoodie/beige_hoodie_grasp_2025-07-18-17-33-48'
    model_file='/home/hwk/program/cloth_simulation_benchmark/assets/mujoco_model/Style3dCloth_NewPiper_Camera.xml'
    # for k1
    # data_path = '/home/hwk/DataSets/K1_Data/2025-07-22-21-46-58'
    # data_path = '/home/hwk/DataSets/K1_Data/2025-07-22-22-22-35'

    target_camera = 'video_third_view'  # 你可以根据需要修改这个相机名称

    # debug 1: manual set
    active_run_for_debug = {
        'cloth': {
            'name': 'green_tshirt',
            'sample_id': 2,
            # 'model_path': f'{os.environ["HOME"]}/DataSets/Style3dCloth/LargeT_Flat_Simple_10k.obj',
            'model_path': f'{os.environ["HOME"]}/DataSets/Style3dCloth/Beige_Hoodie/Hoodie_Flat_Simple_25k_adjusted.obj',
            # 'init_pose': [0.1, 0.0, 0.01, 1.0, 0.0, 0.0, 0.0], # [x, y, z, w, qx, qy, qz]
            'init_pose': [0.158, 0.0, 0.01, 1.0, 0.0, 0.0, 0.0], # [x, y, z, w, qx, qy, qz]
            # 'init_pose': [0.1, 0.0, 0.0, 0.5, 0.5, 0.5, 0.5], # [x, y, z, w, qx, qy, qz]
            'init_pose_path': '/path/to/non_existent_file.json',
        },
        'cloth_params': {
            'shoulder_index': [185, 76],  # Indices of the vertices to pin in fling mode
            'mass': 0.255,
            'stretch': 230000,
            'bending': 1000.0,
            'friction': 0.2,  # friction coefficient
            'poisson': 0.35,
            'damping': 0.0,  # damping coefficient
        },
        'sim_model': {
            "type": "robot",
            'robot': "piper",
        },
        'env': {
            'name': 'mujoco_style3d',
            'model_path': f'{os.environ["HOME"]}/program/cloth_simulation_benchmark/assets/mujoco_model/Style3dCloth_NewPiper_Camera.xml',
            # 'model_path': f'{os.environ["HOME"]}/program/cloth_simulation_benchmark/assets/mujoco_model/Style3dCloth_K1.xml',
            'sim_flex_name': 'cloth',
            'timestep': 0.002
        },
        'data': {
            'root': data_path,
            'robot_joints': {
                'left_arm_csv_path':  osp.join(data_path, "joints","left_arm_joint_states_and_end_pose.csv"),
                'right_arm_csv_path': osp.join(data_path, "joints","right_arm_joint_states_and_end_pose.csv"),
            },
            'sim_start_time': 3.0,
        },
    }
    cfg = OmegaConf.create(active_run_for_debug)



    # debug 2: load from config file
    # debug_config_path = os.path.join(PROJECT_ROOT, "config/main.yaml")
    # cfg = OmegaConf.load(debug_config_path).active_run
    # cfg.env = active_run_for_debug['env']

    try:
        player = MujocoStyle3dEnv(cfg=cfg)

        # Option 1: Interactive Preview
        print("\nStarting interactive simulation...")
        # sim_ver = player.get_sim_vertices()
        player.run()


        # Option 2: Record a video of the same duration as the CSV data (1x speed)
        print("\n--- Recording video at 1.0x speed (real-time match) ---")
        output_filename = f"{data_path}/video/simulation_{target_camera}_step_{player.model.opt.timestep}_40k.mp4"
        # player.record_video(
        #     output_path= output_filename,  # use default path
        #     speed=1.0,
        #     camera_name=target_camera,  # use view
        #     fps=120,
        # )

    except FileNotFoundError as e:
        print(f"Error: File not found. Please check paths. Details: {e}")
    except ValueError as e:
        print(f"Error: Value error during initialization or data loading. Details: {e}")
    except Exception as e: # 其他未知错误
        print(f"An unexpected error occurred: {e}")
        import traceback
        traceback.print_exc()